<?php
require_once 'config.php';

if (!isAdminLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);

$name = sanitize($data['name'] ?? '');
$logo = sanitize($data['logo'] ?? '');
$stream_url = sanitize($data['stream_url'] ?? '');
$category = sanitize($data['category'] ?? 'General');
$country = sanitize($data['country'] ?? 'Global');

if (empty($name) || empty($stream_url)) {
    echo json_encode(['success' => false, 'error' => 'Name and Stream URL are required']);
    exit();
}

$conn = getDBConnection();

$stmt = $conn->prepare("INSERT INTO channels (name, logo, stream_url, category, country, enabled) VALUES (?, ?, ?, ?, ?, 1)");
$stmt->bind_param("sssss", $name, $logo, $stream_url, $category, $country);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'id' => $stmt->insert_id]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

$stmt->close();
$conn->close();
?>